package member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class MemberDAO {
	private Connection conn;
	private Context init;
	private DataSource ds;
	private Statement stmt;
	private ResultSet rs;
	private PreparedStatement pstmt;
	
	private static MemberDAO instance = new MemberDAO();
	
	public static MemberDAO getInstance() {
		return instance;
	}
	
	private MemberDAO() {
		try {
			init = (Context)new InitialContext();
			ds = (DataSource) init.lookup("java:comp/env/jdbc/oracle");
		}catch(Exception e) {
			System.out.println("생성자 예외 발생 : "+ e);
		}finally {
			if(conn != null) try {conn.close();} catch(Exception e) {}
		}
	}

	// close 함수
	private void close() {
		try {
			if(rs != null) 		rs.close(); 
			if(stmt != null) 	stmt.close(); 
			if(conn != null) 	conn.close(); 
		} catch(Exception e) {}
	}

	// 회원 가입
	public int insertMember(MemberDTO dto) {
		String sql = "insert into member (id, password,name,gender,email) "
				+ "values (?,?,?,?,?)";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, Hash.getHash(dto.getPassword()));
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getGender());
			pstmt.setString(5, dto.getEmail());
			int row = pstmt.executeUpdate();
			return row;
		}catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("고유키 제약 조건 위배 : " + e);
			return -1;
		}catch(SQLException e) {
			System.out.println("회원가입  오류 : " + e);
		}finally {
			close();
		}return 0;
		
		
	}
	
	
	// 로그인
	public MemberDTO selectOne(MemberDTO dto) {
		MemberDTO login = new MemberDTO();
		String sql ="select * from member where id=? and password=?";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, Hash.getHash(dto.getPassword()));
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				login.setEmail(rs.getString("email"));
				login.setGender(rs.getString("gender"));
				login.setId(rs.getString("id"));
				login.setIdx(rs.getInt("idx"));
				login.setName(rs.getString("name"));
				login.setPassword(rs.getString("password"));
				System.out.println(login);
				return login;
			}
		}catch(SQLException e) {
			System.out.println("로그인 sql 오류 : " + e);
		}finally {
			close();
		}return null;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
