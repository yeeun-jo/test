package survey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class SurveyDAO {

	private Connection conn;
	private Context init;
	private DataSource ds;
	private Statement stmt;
	private ResultSet rs;
	private PreparedStatement pstmt;
	
	private static SurveyDAO instance = new SurveyDAO();
	
	public static SurveyDAO getInstance() {
		return instance;
	}
	
	private SurveyDAO() {
		try {
			init = (Context)new InitialContext();
			ds = (DataSource) init.lookup("java:comp/env/jdbc/oracle");
		}catch(Exception e) {
			System.out.println("생성자 예외 발생 : "+ e);
		}finally {
			if(conn != null) try {conn.close();} catch(Exception e) {}
		}
	}

	// close 함수
	private void close() {
		try {
			if(rs != null) 		rs.close(); 
			if(stmt != null) 	stmt.close(); 
			if(conn != null) 	conn.close(); 
		} catch(Exception e) {}
	}

	
	
	// 설문조사 내용 입력
	public int insertSurvey(SurveyDTO dto) {
		String sql = "insert into survey (ididx,context) values (?, ?)";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getIdidx());
			pstmt.setString(2, dto.getContext());
			int row = pstmt.executeUpdate();
			return row;
		}catch(SQLException e	) {
			System.out.println("설문조사 입력 오류 : "+ e);
		}finally {
			close();
		}
		return 0;
	}
	
	// 설문조사 전체  내용 보여주기
	public List<SurveyDTO> selectAll() {
		ArrayList<SurveyDTO> list = new ArrayList<SurveyDTO>();
		String sql = "select survey.*,member.id,member.name from survey,member where survey.ididx=member.idx "
				+ "order by survey.idx desc";
		
		try {
			conn = ds.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				SurveyDTO dto = new SurveyDTO();
				dto.setContext(rs.getString("context"));
				dto.setCreatdate(rs.getDate("creatdate"));
				dto.setId(rs.getString("id"));
				dto.setIdidx(rs.getInt("ididx"));
				dto.setName(rs.getString("name"));
				dto.setIdx(rs.getInt("idx"));
				list.add(dto);
			}
			return list;
		}catch(SQLException e){
			System.out.println("설문조사 보여주기 오류 : "+ e);
		}finally {
			close();
		}return null;
	}
	
	// 설문 내용 보기
	public SurveyDTO selectOne(int idx) {
		String sql ="select survey.*,member.id,member.name from survey,member where survey.ididx=member.idx and survey.idx="+idx;
		try {
			conn = ds.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				SurveyDTO dto = new SurveyDTO();
				dto.setContext(rs.getString("context"));
				dto.setCreatdate(rs.getDate("creatdate"));
				dto.setId(rs.getString("id"));
				dto.setIdx(rs.getInt("idx"));
				dto.setIdidx(rs.getInt("ididx"));
				dto.setName(rs.getString("name"));
				System.out.println(dto);
				return dto;
			}
		}catch(SQLException e) {
			System.out.println("설문내용보기 오류 : "+ e);
		}finally {
			close();
		}return null;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
