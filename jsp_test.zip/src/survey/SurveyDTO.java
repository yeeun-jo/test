package survey;

import java.util.Date;

public class SurveyDTO {
//	IDX       NOT NULL NUMBER        
//	IDIDX     NOT NULL NUMBER        
//	CREATDATE          DATE          
//	CONTEXT            VARCHAR2(500) 
	
//	ID       NOT NULL VARCHAR2(20) from member 
//	NAME              VARCHAR2(20) 

	private int idx, ididx;
	private String context;
	private Date creatdate;
	
	private String id, name;

	public int getIdx() {
		return idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public int getIdidx() {
		return ididx;
	}

	public void setIdidx(int ididx) {
		this.ididx = ididx;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public Date getCreatdate() {
		return creatdate;
	}

	public void setCreatdate(Date creatdate) {
		this.creatdate = creatdate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
