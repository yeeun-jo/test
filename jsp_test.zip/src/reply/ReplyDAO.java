package reply;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class ReplyDAO {
	private Connection conn;
	private Context init;
	private DataSource ds;
	private Statement stmt;
	private ResultSet rs;
	
	private static ReplyDAO instance = new ReplyDAO();
	
	public static ReplyDAO getInstance() {
		return instance;
	}
	
	private ReplyDAO() {
		try {
			init = (Context)new InitialContext();
			ds = (DataSource) init.lookup("java:comp/env/jdbc/oracle");
		}catch(Exception e) {
			System.out.println("생성자 예외 발생 : "+ e);
		}finally {
			if(conn != null) try {conn.close();} catch(Exception e) {}
		}
	}

	// close 함수
	private void close() {
		try {
			if(rs != null) 		rs.close(); 
			if(stmt != null) 	stmt.close(); 
			if(conn != null) 	conn.close(); 
		} catch(Exception e) {}
	}

	// 해당 설문에 대한 응답만 보여준다
	/*
	 * public List<ReplyDTO> selectList(int idx){ ArrayList<ReplyDTO> list = new
	 * ArrayList<ReplyDTO>();
	 * 
	 * String sql = "select member.id, member.name, reply.* from member,reply" +
	 * "				where member.idx=reply.ididx and reply.surveyidx=" + idx;
	 * 
	 * 
	 * try { conn = ds.getConnection(); stmt = conn.createStatement(); rs =
	 * stmt.executeQuery(sql); while(rs.next()) { ReplyDTO dto = new ReplyDTO();
	 * dto.setIdx(rs.getInt("idx")); dto.setSurveyidx(rs.getInt("surveyidx"));
	 * dto.setIdidx(rs.getInt("ididx")); dto.setAnswer(rs.getString("answer"));
	 * dto.setId(rs.getString("id")); dto.setName(rs.getString("name"));
	 * 
	 * list.add(dto); } return list; }catch(SQLException e ) {
	 * System.out.println("응 답 오 류 : " + e); }finally { close(); } return null; }
	 */
	
	// 설문 응답하기 
		public int insertReply(ReplyDTO result) {
			String sql ="insert into reply (surveyidx,ididx,answer) values(%d,%d,'%s')";
			sql = String.format(sql, result.getSurveyidx(),result.getIdidx(),result.getAnswer());
			
			try {
				conn = ds.getConnection();
				stmt = conn.createStatement();
				int row =stmt.executeUpdate(sql);
				
				return row;
			}catch(SQLException e	) {
				System.out.println("설문 응답 오류 : "+ e);
			}finally {
				close();
			}
			return 0;
		}
		
		// 응답 갯수
		public int countAll(int idx) {
			String sql = "select count(*) from " + 
					"				(select member.id, member.name, reply.* from member,reply" + 
					"				where member.idx=reply.ididx and reply.surveyidx=%d)";
			
			sql = String.format(sql, idx);
			try {
				conn = ds.getConnection();
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);
				
				while(rs.next()) {
					int count = rs.getInt(1);
					return count;
				}
			}catch(SQLException e) {
				System.out.println("응답 총 수량 오류: "+ e);
			}finally {
				close();
			}
			return 0;
		}
	
		// yes라고 응답한 수량
		public int selectAnswer(int idx) {
			String sql = "select count(*) from" + 
					"				(select member.id, member.name, reply.* from member,reply" + 
					"				where member.idx=reply.ididx and reply.surveyidx=%d" + 
					"                and reply.answer='YES')";
			
			sql = String.format(sql, idx);
			int result = 0;
			try {
				conn = ds.getConnection();
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);
				
				while(rs.next()) {
					result = rs.getInt(1);
				}
				return result;
			}catch(SQLException e) {
				System.out.println("대답 오류 : " + e);
			}finally {
				close();
			}return 0;
			
			
		}
	
	
	
}
