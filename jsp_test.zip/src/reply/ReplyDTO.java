package reply;

public class ReplyDTO {

//	IDX       NOT NULL NUMBER       
//	SURVEYIDX NOT NULL NUMBER       
//	IDIDX     NOT NULL NUMBER       
//	CONTEXT   NOT NULL VARCHAR2(20) 
	
//	ID       NOT NULL VARCHAR2(20) from member 
//	NAME              VARCHAR2(20) 
	
//	IDX       NOT NULL NUMBER        from survey;
//	IDIDX     NOT NULL NUMBER        
	
	private int idx,surveyidx,ididx;
	private String answer;
	
	private String id,name;
	
	
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getSurveyidx() {
		return surveyidx;
	}
	public void setSurveyidx(int surveyidx) {
		this.surveyidx = surveyidx;
	}
	public int getIdidx() {
		return ididx;
	}
	public void setIdidx(int ididx) {
		this.ididx = ididx;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
}
